from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from rest_framework.authtoken.models import Token

from .models import Profile


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_profile_and_token(sender, instance, created, **kwargs):
    """Whenever a new User is created, give them a Profile and an auth Token automatically."""
    if created:
        Profile.objects.create(user=instance)
        Token.objects.create(user=instance)
