from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404
from rest_framework import generics, status, permissions
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Profile, Post, Comment, Like, Follow
from .serializers import (
    RegisterSerializer, LoginSerializer, ProfileSerializer, ProfileUpdateSerializer,
    PostSerializer, PostDetailSerializer, CommentSerializer, FollowUserSerializer,
)


class IsAuthorOrReadOnly(permissions.BasePermission):
    """Only the author of a post/comment can edit or delete it; everyone else gets read-only."""

    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        return obj.author == request.user


# ==================== Auth ====================

class RegisterView(generics.CreateAPIView):
    permission_classes = [permissions.AllowAny]
    serializer_class = RegisterSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        token, _ = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'username': user.username,
        }, status=status.HTTP_201_CREATED)


class LoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = authenticate(
            username=serializer.validated_data['username'],
            password=serializer.validated_data['password'],
        )
        if user is None:
            return Response({'detail': 'Invalid username or password.'},
                             status=status.HTTP_401_UNAUTHORIZED)
        token, _ = Token.objects.get_or_create(user=user)
        return Response({'token': token.key, 'username': user.username})


class LogoutView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        request.user.auth_token.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class MeView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        profile = request.user.profile
        return Response(ProfileSerializer(profile, context={'request': request}).data)


# ==================== Profiles ====================

class ProfileDetailView(APIView):
    """GET /api/users/<username>/  — public profile view."""
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get(self, request, username):
        user = get_object_or_404(User, username__iexact=username)
        return Response(ProfileSerializer(user.profile, context={'request': request}).data)


class ProfileUpdateView(generics.UpdateAPIView):
    """PATCH/PUT /api/users/me/  — update your own bio/avatar."""
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = ProfileUpdateSerializer

    def get_object(self):
        return self.request.user.profile

    def update(self, request, *args, **kwargs):
        super().update(request, *args, **kwargs)
        return Response(ProfileSerializer(self.request.user.profile, context={'request': request}).data)


# ==================== Posts ====================

class FeedView(generics.ListCreateAPIView):
    """
    GET  /api/posts/            -> all posts (global feed), newest first
    GET  /api/posts/?feed=following -> only posts from people you follow
    POST /api/posts/            -> create a new post
    """
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    serializer_class = PostSerializer

    def get_queryset(self):
        qs = Post.objects.select_related('author', 'author__profile').prefetch_related('likes', 'comments')
        if self.request.query_params.get('feed') == 'following' and self.request.user.is_authenticated:
            following_ids = Follow.objects.filter(follower=self.request.user).values_list('following_id', flat=True)
            qs = qs.filter(author_id__in=following_ids)
        return qs

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)

    def get_serializer_context(self):
        return {'request': self.request}


class PostDetailView(generics.RetrieveDestroyAPIView):
    """
    GET    /api/posts/<id>/  -> post with its comments
    DELETE /api/posts/<id>/  -> delete (author only)
    """
    queryset = Post.objects.all()
    serializer_class = PostDetailSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly, IsAuthorOrReadOnly]

    def get_serializer_context(self):
        return {'request': self.request}


class UserPostsView(generics.ListAPIView):
    """GET /api/users/<username>/posts/ — all posts by one user."""
    serializer_class = PostSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        username = self.kwargs['username']
        return Post.objects.filter(author__username__iexact=username)

    def get_serializer_context(self):
        return {'request': self.request}


# ==================== Comments ====================

class CommentListCreateView(generics.ListCreateAPIView):
    """
    GET  /api/posts/<post_id>/comments/  -> list comments on a post
    POST /api/posts/<post_id>/comments/  -> add a comment
    """
    serializer_class = CommentSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        return Comment.objects.filter(post_id=self.kwargs['post_id'])

    def perform_create(self, serializer):
        post = get_object_or_404(Post, pk=self.kwargs['post_id'])
        serializer.save(author=self.request.user, post=post)


class CommentDeleteView(generics.DestroyAPIView):
    """DELETE /api/comments/<id>/ — author only."""
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer
    permission_classes = [permissions.IsAuthenticated, IsAuthorOrReadOnly]


# ==================== Likes ====================

class LikeToggleView(APIView):
    """
    POST   /api/posts/<post_id>/like/  -> like the post
    DELETE /api/posts/<post_id>/like/  -> unlike the post
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, post_id):
        post = get_object_or_404(Post, pk=post_id)
        _, created = Like.objects.get_or_create(post=post, user=request.user)
        return Response({
            'liked': True,
            'likes_count': post.likes.count(),
        }, status=status.HTTP_201_CREATED if created else status.HTTP_200_OK)

    def delete(self, request, post_id):
        post = get_object_or_404(Post, pk=post_id)
        Like.objects.filter(post=post, user=request.user).delete()
        return Response({
            'liked': False,
            'likes_count': post.likes.count(),
        })


# ==================== Follow ====================

class FollowToggleView(APIView):
    """
    POST   /api/users/<username>/follow/  -> follow a user
    DELETE /api/users/<username>/follow/  -> unfollow a user
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, username):
        target = get_object_or_404(User, username__iexact=username)
        if target == request.user:
            return Response({'detail': "You can't follow yourself."}, status=status.HTTP_400_BAD_REQUEST)
        _, created = Follow.objects.get_or_create(follower=request.user, following=target)
        return Response({
            'following': True,
            'followers_count': Follow.objects.filter(following=target).count(),
        }, status=status.HTTP_201_CREATED if created else status.HTTP_200_OK)

    def delete(self, request, username):
        target = get_object_or_404(User, username__iexact=username)
        Follow.objects.filter(follower=request.user, following=target).delete()
        return Response({
            'following': False,
            'followers_count': Follow.objects.filter(following=target).count(),
        })


class FollowersListView(generics.ListAPIView):
    """GET /api/users/<username>/followers/"""
    serializer_class = FollowUserSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        user = get_object_or_404(User, username__iexact=self.kwargs['username'])
        return Follow.objects.filter(following=user).select_related('follower__profile')

    def get_serializer(self, *args, **kwargs):
        # Remap queryset (Follow objects) -> the follower User, for the serializer's `source='user...'` fields
        qs = args[0] if args else self.get_queryset()
        wrapped = [type('Row', (), {'user': f.follower})() for f in qs]
        return super().get_serializer(wrapped, many=True, **kwargs)


class FollowingListView(generics.ListAPIView):
    """GET /api/users/<username>/following/"""
    serializer_class = FollowUserSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        user = get_object_or_404(User, username__iexact=self.kwargs['username'])
        return Follow.objects.filter(follower=user).select_related('following__profile')

    def get_serializer(self, *args, **kwargs):
        qs = args[0] if args else self.get_queryset()
        wrapped = [type('Row', (), {'user': f.following})() for f in qs]
        return super().get_serializer(wrapped, many=True, **kwargs)
