from django.urls import path
from . import views

urlpatterns = [
    # Auth
    path('auth/register/', views.RegisterView.as_view(), name='register'),
    path('auth/login/', views.LoginView.as_view(), name='login'),
    path('auth/logout/', views.LogoutView.as_view(), name='logout'),
    path('auth/me/', views.MeView.as_view(), name='me'),

    # Posts & feed
    path('posts/', views.FeedView.as_view(), name='feed'),
    path('posts/<int:pk>/', views.PostDetailView.as_view(), name='post-detail'),
    path('posts/<int:post_id>/like/', views.LikeToggleView.as_view(), name='post-like'),
    path('posts/<int:post_id>/comments/', views.CommentListCreateView.as_view(), name='post-comments'),

    # Comments
    path('comments/<int:pk>/', views.CommentDeleteView.as_view(), name='comment-delete'),

    # Profiles / follow
    path('users/<str:username>/', views.ProfileDetailView.as_view(), name='profile-detail'),
    path('users/me/update/', views.ProfileUpdateView.as_view(), name='profile-update'),
    path('users/<str:username>/posts/', views.UserPostsView.as_view(), name='user-posts'),
    path('users/<str:username>/follow/', views.FollowToggleView.as_view(), name='follow-toggle'),
    path('users/<str:username>/followers/', views.FollowersListView.as_view(), name='followers-list'),
    path('users/<str:username>/following/', views.FollowingListView.as_view(), name='following-list'),
]
