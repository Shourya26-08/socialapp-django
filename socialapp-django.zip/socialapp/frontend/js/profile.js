// ============================================================
// profile.js — logic for the profile page (profile.html?u=username).
// ============================================================

renderNav('profile');
if (requireLoginOrRedirect()) {
  init();
}

const params = new URLSearchParams(window.location.search);
const viewedUsername = params.get('u') || Api.getUsername();

async function init() {
  const root = document.getElementById('profile-root');
  const errorSlot = document.getElementById('error-slot');
  try {
    const [profile, posts] = await Promise.all([
      Api.getProfile(viewedUsername),
      Api.getUserPosts(viewedUsername),
    ]);
    renderProfile(profile);
    renderPosts(posts.results !== undefined ? posts.results : posts);
  } catch (err) {
    root.innerHTML = '';
    showError(errorSlot, err);
  }
}

function renderProfile(profile) {
  const root = document.getElementById('profile-root');
  const isOwnProfile = profile.is_following === null;

  root.innerHTML = `
    <section class="profile-header">
      <div class="profile-top-row">
        <div>
          <div class="profile-avatar" id="avatar-slot">${
            profile.avatar_url
              ? `<img src="${escapeHtml(profile.avatar_url)}" alt="" style="width:100%;height:100%;border-radius:50%;object-fit:cover;" />`
              : initials(profile.username)
          }</div>
        </div>
        <div style="flex:1;">
          <h1 class="profile-name">@${escapeHtml(profile.username)}</h1>
          <div class="profile-username">Joined ${new Date(profile.date_joined).toLocaleDateString(undefined, { year: 'numeric', month: 'long' })}</div>
        </div>
        <div>
          ${isOwnProfile
            ? `<button class="btn btn-outline btn-small" id="edit-profile-btn">Edit profile</button>`
            : `<button class="btn ${profile.is_following ? 'btn-outline' : 'btn-signal'} btn-small" id="follow-btn" data-following="${profile.is_following}">${profile.is_following ? 'Following' : 'Follow'}</button>`
          }
        </div>
      </div>

      ${profile.bio ? `<p class="profile-bio">${escapeHtml(profile.bio)}</p>` : (isOwnProfile ? `<p class="profile-bio composer-hint">Add a bio so people know what you're about.</p>` : '')}

      <div class="profile-stats">
        <span><strong>${profile.posts_count}</strong> posts</span>
        <button type="button" id="followers-btn"><strong>${profile.followers_count}</strong> followers</button>
        <button type="button" id="following-btn"><strong>${profile.following_count}</strong> following</button>
      </div>
    </section>

    <div id="edit-form-slot"></div>
    <div id="posts-list"></div>
  `;

  document.getElementById('followers-btn').addEventListener('click', () => openListModal('followers', profile.username));
  document.getElementById('following-btn').addEventListener('click', () => openListModal('following', profile.username));

  if (isOwnProfile) {
    document.getElementById('edit-profile-btn').addEventListener('click', () => openEditForm(profile));
  } else {
    document.getElementById('follow-btn').addEventListener('click', () => toggleFollow(profile.username));
  }
}

function openEditForm(profile) {
  const slot = document.getElementById('edit-form-slot');
  slot.innerHTML = `
    <form id="edit-profile-form" style="margin-bottom:24px; border-bottom:1px solid var(--rule); padding-bottom:20px;">
      <div class="field">
        <label for="edit-bio">Bio</label>
        <textarea id="edit-bio" maxlength="280">${escapeHtml(profile.bio)}</textarea>
      </div>
      <div class="field">
        <label for="edit-avatar">Avatar image URL (optional)</label>
        <input type="url" id="edit-avatar" value="${escapeHtml(profile.avatar_url)}" placeholder="https://…" />
      </div>
      <button type="submit" class="btn btn-signal btn-small">Save changes</button>
      <button type="button" class="btn btn-outline btn-small" id="cancel-edit-btn">Cancel</button>
    </form>
  `;
  document.getElementById('cancel-edit-btn').addEventListener('click', () => { slot.innerHTML = ''; });
  document.getElementById('edit-profile-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const bio = document.getElementById('edit-bio').value.trim();
    const avatar_url = document.getElementById('edit-avatar').value.trim();
    try {
      const updated = await Api.updateProfile(bio, avatar_url);
      showToast('Profile updated.');
      slot.innerHTML = '';
      renderProfile(updated);
    } catch (err) {
      showToast(err.message || 'Could not save changes.');
    }
  });
}

async function toggleFollow(username) {
  const btn = document.getElementById('follow-btn');
  const currentlyFollowing = btn.dataset.following === 'true';
  btn.disabled = true;
  try {
    const result = currentlyFollowing ? await Api.unfollow(username) : await Api.follow(username);
    btn.dataset.following = result.following;
    btn.textContent = result.following ? 'Following' : 'Follow';
    btn.classList.toggle('btn-signal', !result.following);
    btn.classList.toggle('btn-outline', result.following);
    document.querySelector('#followers-btn strong').textContent = result.followers_count;
  } catch (err) {
    showToast(err.message || 'Could not update follow status.');
  } finally {
    btn.disabled = false;
  }
}

function renderPosts(posts) {
  const listEl = document.getElementById('posts-list');
  if (!posts || posts.length === 0) {
    listEl.innerHTML = `<div class="empty-state">No posts yet.</div>`;
    return;
  }
  listEl.innerHTML = posts.map((post) => `
    <article class="entry" data-post-id="${post.id}">
      <div class="entry-byline">
        <span class="avatar-dot">${initials(post.author.username)}</span>
        <span class="author-name">@${escapeHtml(post.author.username)}</span>
        <span class="timestamp">${timeAgo(post.created_at)}</span>
      </div>
      <p class="entry-content">${escapeHtml(post.content)}</p>
      ${post.image_url ? `<img class="entry-image" src="${escapeHtml(post.image_url)}" alt="" />` : ''}
      <div class="entry-actions">
        <span class="entry-action">♡ ${post.likes_count}</span>
        <span class="entry-action">💬 ${post.comments_count}</span>
        ${post.author.username === Api.getUsername() ? `<button type="button" class="entry-action delete-action" data-post-id="${post.id}" onclick="deletePostFromProfile(${post.id})">Delete</button>` : ''}
      </div>
    </article>
  `).join('');
}

async function deletePostFromProfile(postId) {
  if (!confirm('Delete this post?')) return;
  try {
    await Api.deletePost(postId);
    document.querySelector(`.entry[data-post-id="${postId}"]`)?.remove();
    showToast('Post deleted.');
  } catch (err) {
    showToast(err.message || 'Could not delete post.');
  }
}

async function openListModal(kind, username) {
  const modalSlot = document.getElementById('modal-slot');
  modalSlot.innerHTML = `
    <div class="modal-backdrop" id="modal-backdrop">
      <div class="modal">
        <div class="modal-header">
          <span>${kind === 'followers' ? 'Followers' : 'Following'}</span>
          <button type="button" id="modal-close-btn">&times;</button>
        </div>
        <div id="modal-body"><div class="loading-state">Loading…</div></div>
      </div>
    </div>
  `;
  document.getElementById('modal-backdrop').addEventListener('click', (e) => {
    if (e.target.id === 'modal-backdrop') modalSlot.innerHTML = '';
  });
  document.getElementById('modal-close-btn').addEventListener('click', () => { modalSlot.innerHTML = ''; });

  try {
    const list = kind === 'followers' ? await Api.getFollowers(username) : await Api.getFollowing(username);
    const rows = list.results !== undefined ? list.results : list;
    const body = document.getElementById('modal-body');
    if (!rows || rows.length === 0) {
      body.innerHTML = `<div class="empty-state">Nobody here yet.</div>`;
      return;
    }
    body.innerHTML = rows.map((row) => `
      <a class="modal-list-row" href="profile.html?u=${encodeURIComponent(row.username)}">
        <span class="avatar-dot">${initials(row.username)}</span>
        <span>@${escapeHtml(row.username)}</span>
      </a>
    `).join('');
  } catch (err) {
    document.getElementById('modal-body').innerHTML = `<div class="error-banner">${escapeHtml(err.message || 'Could not load list.')}</div>`;
  }
}
