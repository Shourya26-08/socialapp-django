// ============================================================
// api.js — thin wrapper around fetch() for the Django REST API.
// Handles token storage and attaches the Authorization header.
// ============================================================

const API_BASE = 'http://127.0.0.1:8000/api';

const Api = {
  getToken() {
    return localStorage.getItem('authToken');
  },
  setToken(token) {
    localStorage.setItem('authToken', token);
  },
  clearToken() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('authUsername');
  },
  getUsername() {
    return localStorage.getItem('authUsername');
  },
  setUsername(username) {
    localStorage.setItem('authUsername', username);
  },
  isLoggedIn() {
    return !!this.getToken();
  },

  async request(path, { method = 'GET', body = null } = {}) {
    const headers = { 'Content-Type': 'application/json' };
    const token = this.getToken();
    if (token) headers['Authorization'] = `Token ${token}`;

    let response;
    try {
      response = await fetch(`${API_BASE}${path}`, {
        method,
        headers,
        body: body ? JSON.stringify(body) : null,
      });
    } catch (networkErr) {
      throw new Error('Could not reach the server. Is the Django backend running on port 8000?');
    }

    if (response.status === 204) return null;

    let data;
    try {
      data = await response.json();
    } catch {
      data = null;
    }

    if (!response.ok) {
      const message =
        (data && (data.detail || firstErrorMessage(data))) ||
        `Request failed (${response.status})`;
      throw new Error(message);
    }
    return data;
  },

  // ---------- Auth ----------
  register(username, email, password, bio) {
    return this.request('/auth/register/', { method: 'POST', body: { username, email, password, bio } });
  },
  login(username, password) {
    return this.request('/auth/login/', { method: 'POST', body: { username, password } });
  },
  logout() {
    return this.request('/auth/logout/', { method: 'POST' }).catch(() => null);
  },
  me() {
    return this.request('/auth/me/');
  },

  // ---------- Profiles ----------
  getProfile(username) {
    return this.request(`/users/${encodeURIComponent(username)}/`);
  },
  updateProfile(bio, avatar_url) {
    return this.request('/users/me/update/', { method: 'PATCH', body: { bio, avatar_url } });
  },
  getFollowers(username) {
    return this.request(`/users/${encodeURIComponent(username)}/followers/`);
  },
  getFollowing(username) {
    return this.request(`/users/${encodeURIComponent(username)}/following/`);
  },
  follow(username) {
    return this.request(`/users/${encodeURIComponent(username)}/follow/`, { method: 'POST' });
  },
  unfollow(username) {
    return this.request(`/users/${encodeURIComponent(username)}/follow/`, { method: 'DELETE' });
  },

  // ---------- Posts ----------
  getFeed(mode = 'all') {
    const query = mode === 'following' ? '?feed=following' : '';
    return this.request(`/posts/${query}`);
  },
  getUserPosts(username) {
    return this.request(`/users/${encodeURIComponent(username)}/posts/`);
  },
  getPost(id) {
    return this.request(`/posts/${id}/`);
  },
  createPost(content, image_url) {
    return this.request('/posts/', { method: 'POST', body: { content, image_url } });
  },
  deletePost(id) {
    return this.request(`/posts/${id}/`, { method: 'DELETE' });
  },

  // ---------- Likes ----------
  like(postId) {
    return this.request(`/posts/${postId}/like/`, { method: 'POST' });
  },
  unlike(postId) {
    return this.request(`/posts/${postId}/like/`, { method: 'DELETE' });
  },

  // ---------- Comments ----------
  getComments(postId) {
    return this.request(`/posts/${postId}/comments/`);
  },
  addComment(postId, content) {
    return this.request(`/posts/${postId}/comments/`, { method: 'POST', body: { content } });
  },
  deleteComment(commentId) {
    return this.request(`/comments/${commentId}/`, { method: 'DELETE' });
  },
};

function firstErrorMessage(data) {
  if (!data || typeof data !== 'object') return null;
  const firstKey = Object.keys(data)[0];
  if (!firstKey) return null;
  const val = data[firstKey];
  return Array.isArray(val) ? `${firstKey}: ${val[0]}` : String(val);
}
