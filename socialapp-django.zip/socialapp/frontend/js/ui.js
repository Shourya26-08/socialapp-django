// ============================================================
// ui.js — small shared helpers used by every page.
// ============================================================

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

function initials(username) {
  return (username || '?').trim().charAt(0).toUpperCase();
}

function timeAgo(isoString) {
  const seconds = Math.floor((Date.now() - new Date(isoString).getTime()) / 1000);
  const units = [
    ['year', 31536000], ['month', 2592000], ['day', 86400],
    ['hour', 3600], ['minute', 60],
  ];
  for (const [name, secondsInUnit] of units) {
    const value = Math.floor(seconds / secondsInUnit);
    if (value >= 1) return `${value}${name[0]}`;
  }
  return 'just now';
}

let toastTimer = null;
function showToast(message) {
  let el = document.getElementById('toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    el.className = 'toast';
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 2600);
}

function showError(container, err) {
  const message = err && err.message ? err.message : 'Something went wrong.';
  container.innerHTML = `<div class="error-banner">${escapeHtml(message)}</div>`;
}

function requireLoginOrRedirect() {
  if (!Api.isLoggedIn()) {
    window.location.href = 'login.html';
    return false;
  }
  return true;
}

function renderNav(activePage) {
  const nav = document.getElementById('nav-slot');
  if (!nav) return;
  const username = Api.getUsername();
  if (Api.isLoggedIn()) {
    nav.innerHTML = `
      <a href="index.html" class="${activePage === 'home' ? 'active-link' : ''}">Feed</a>
      <a href="profile.html?u=${encodeURIComponent(username)}" class="${activePage === 'profile' ? 'active-link' : ''}">My profile</a>
      <span class="current-user">@${escapeHtml(username)}</span>
      <button id="logout-btn" type="button">Log out</button>
    `;
    document.getElementById('logout-btn').addEventListener('click', async () => {
      await Api.logout();
      Api.clearToken();
      window.location.href = 'login.html';
    });
  } else {
    nav.innerHTML = `
      <a href="login.html">Log in</a>
      <a href="register.html">Sign up</a>
    `;
  }
}
