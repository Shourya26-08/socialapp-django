// ============================================================
// feed.js — logic for the home feed page (index.html).
// ============================================================

renderNav('home');
if (requireLoginOrRedirect()) {
  init();
}

let currentMode = 'all';

async function init() {
  bindComposer();
  bindTabs();
  await loadFeed();
}

function bindComposer() {
  const form = document.getElementById('post-form');
  const submitBtn = document.getElementById('post-submit-btn');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const textarea = document.getElementById('post-content');
    const content = textarea.value.trim();
    if (!content) return;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Posting…';
    try {
      await Api.createPost(content, '');
      textarea.value = '';
      showToast('Posted.');
      await loadFeed();
    } catch (err) {
      showToast(err.message || 'Could not post.');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Post';
    }
  });
}

function bindTabs() {
  document.querySelectorAll('.feed-tab').forEach((tab) => {
    tab.addEventListener('click', async () => {
      document.querySelectorAll('.feed-tab').forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');
      currentMode = tab.dataset.mode;
      await loadFeed();
    });
  });
}

async function loadFeed() {
  const listEl = document.getElementById('feed-list');
  const errorSlot = document.getElementById('error-slot');
  errorSlot.innerHTML = '';
  listEl.innerHTML = '<div class="loading-state">Loading feed…</div>';
  try {
    const data = await Api.getFeed(currentMode);
    const posts = data.results !== undefined ? data.results : data;
    renderFeed(posts);
  } catch (err) {
    listEl.innerHTML = '';
    showError(errorSlot, err);
  }
}

function renderFeed(posts) {
  const listEl = document.getElementById('feed-list');
  if (!posts || posts.length === 0) {
    listEl.innerHTML = `<div class="empty-state">${
      currentMode === 'following'
        ? "No posts yet from people you follow. Try the Everyone tab to find some."
        : "Nothing here yet. Be the first to post something."
    }</div>`;
    return;
  }
  listEl.innerHTML = posts.map(postEntryHtml).join('');
  posts.forEach((post) => bindEntryEvents(post));
}

function postEntryHtml(post) {
  const isMine = post.author.username === Api.getUsername();
  return `
    <article class="entry" data-post-id="${post.id}">
      <div class="entry-byline">
        <span class="avatar-dot">${initials(post.author.username)}</span>
        <a class="author-name" href="profile.html?u=${encodeURIComponent(post.author.username)}">@${escapeHtml(post.author.username)}</a>
        <span class="timestamp">${timeAgo(post.created_at)}</span>
      </div>
      <p class="entry-content">${escapeHtml(post.content)}</p>
      ${post.image_url ? `<img class="entry-image" src="${escapeHtml(post.image_url)}" alt="" />` : ''}
      <div class="entry-actions">
        <button type="button" class="entry-action like-btn ${post.is_liked ? 'liked' : ''}" data-post-id="${post.id}">
          ${post.is_liked ? '♥' : '♡'} <span class="like-count">${post.likes_count}</span>
        </button>
        <button type="button" class="entry-action comment-toggle" data-post-id="${post.id}">
          💬 <span class="comment-count">${post.comments_count}</span>
        </button>
        ${isMine ? `<button type="button" class="entry-action delete-action delete-post-btn" data-post-id="${post.id}">Delete</button>` : ''}
      </div>
      <div class="comments-section hidden" id="comments-${post.id}"></div>
    </article>
  `;
}

function bindEntryEvents(post) {
  const entry = document.querySelector(`.entry[data-post-id="${post.id}"]`);
  if (!entry) return;

  entry.querySelector('.like-btn').addEventListener('click', () => toggleLike(post.id));
  entry.querySelector('.comment-toggle').addEventListener('click', () => toggleComments(post.id));

  const deleteBtn = entry.querySelector('.delete-post-btn');
  if (deleteBtn) {
    deleteBtn.addEventListener('click', () => deletePost(post.id));
  }
}

async function toggleLike(postId) {
  const entry = document.querySelector(`.entry[data-post-id="${postId}"]`);
  const btn = entry.querySelector('.like-btn');
  const countEl = btn.querySelector('.like-count');
  const currentlyLiked = btn.classList.contains('liked');
  try {
    const result = currentlyLiked ? await Api.unlike(postId) : await Api.like(postId);
    btn.classList.toggle('liked', result.liked);
    btn.innerHTML = `${result.liked ? '♥' : '♡'} <span class="like-count">${result.likes_count}</span>`;
  } catch (err) {
    showToast(err.message || 'Could not update like.');
  }
}

async function toggleComments(postId) {
  const section = document.getElementById(`comments-${postId}`);
  const isHidden = section.classList.contains('hidden');
  section.classList.toggle('hidden');
  if (isHidden && !section.dataset.loaded) {
    section.innerHTML = '<div class="loading-state">Loading comments…</div>';
    try {
      const comments = await Api.getComments(postId);
      const list = comments.results !== undefined ? comments.results : comments;
      renderComments(postId, list);
      section.dataset.loaded = 'true';
    } catch (err) {
      section.innerHTML = `<div class="error-banner">${escapeHtml(err.message || 'Could not load comments.')}</div>`;
    }
  }
}

function renderComments(postId, comments) {
  const section = document.getElementById(`comments-${postId}`);
  const rowsHtml = comments.map(commentRowHtml).join('');
  section.innerHTML = `
    ${rowsHtml || '<p class="composer-hint">No comments yet.</p>'}
    <form class="comment-form" data-post-id="${postId}">
      <input type="text" placeholder="Write a comment…" maxlength="500" required />
      <button type="submit" class="btn btn-outline btn-small">Reply</button>
    </form>
  `;
  section.querySelector('.comment-form').addEventListener('submit', (e) => submitComment(e, postId));
}

function commentRowHtml(comment) {
  const isMine = comment.author.username === Api.getUsername();
  return `
    <div class="comment-row" data-comment-id="${comment.id}">
      <div><span class="comment-author">@${escapeHtml(comment.author.username)}</span><span class="comment-text">${escapeHtml(comment.content)}</span></div>
      ${isMine ? `<button type="button" class="comment-delete" data-comment-id="${comment.id}" data-post-id="${comment.post}">✕</button>` : ''}
    </div>
  `;
}

async function submitComment(e, postId) {
  e.preventDefault();
  const input = e.target.querySelector('input');
  const content = input.value.trim();
  if (!content) return;
  try {
    const comment = await Api.addComment(postId, content);
    input.value = '';
    const section = document.getElementById(`comments-${postId}`);
    const emptyHint = section.querySelector('.composer-hint');
    if (emptyHint) emptyHint.remove();
    section.querySelector('.comment-form').insertAdjacentHTML('beforebegin', commentRowHtml(comment));
    bindNewCommentDeleteButtons(postId);
    bumpCommentCount(postId, 1);
  } catch (err) {
    showToast(err.message || 'Could not add comment.');
  }
}

function bindNewCommentDeleteButtons(postId) {
  const section = document.getElementById(`comments-${postId}`);
  section.querySelectorAll('.comment-delete').forEach((btn) => {
    btn.onclick = () => deleteComment(btn.dataset.commentId, btn.dataset.postId || postId);
  });
}

async function deleteComment(commentId, postId) {
  if (!confirm('Delete this comment?')) return;
  try {
    await Api.deleteComment(commentId);
    document.querySelector(`.comment-row[data-comment-id="${commentId}"]`)?.remove();
    bumpCommentCount(postId, -1);
  } catch (err) {
    showToast(err.message || 'Could not delete comment.');
  }
}

function bumpCommentCount(postId, delta) {
  const countEl = document.querySelector(`.entry[data-post-id="${postId}"] .comment-count`);
  if (countEl) countEl.textContent = Math.max(0, parseInt(countEl.textContent, 10) + delta);
}

async function deletePost(postId) {
  if (!confirm('Delete this post? This cannot be undone.')) return;
  try {
    await Api.deletePost(postId);
    document.querySelector(`.entry[data-post-id="${postId}"]`)?.remove();
    showToast('Post deleted.');
  } catch (err) {
    showToast(err.message || 'Could not delete post.');
  }
}

// Delegate comment-delete clicks for rows rendered on initial load
document.addEventListener('click', (e) => {
  if (e.target.matches('.comment-delete') && !e.target.onclick) {
    deleteComment(e.target.dataset.commentId, e.target.dataset.postId);
  }
});
